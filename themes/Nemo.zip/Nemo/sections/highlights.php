<div id="highlights" class="">

    <div class="jumbotron jumbotron-fluid jumbotron-img">
        <div class="container">
            <div class="col-6">
                <h1 class="display-7 text">Núcleo de Estudos em Modelagem Conceitual e Ontologias</h1>
                <a class="btn btn-primary buttom-highlights" href="<?php echo get_permalink('sobre')?>" role="button">CONHEÇA O PROJETO</a>
            </div>
        </div>
    </div>

</div>