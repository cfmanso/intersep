<?php 

$args = array(
    'hide-title' => true,
    'type' => 'image',
);
the_widget('qTranslateXWidget', $args);



?>