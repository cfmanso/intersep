

<?php echo get_hansel_and_gretel_breadcrumbs() ?>